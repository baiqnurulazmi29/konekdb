package com.lepji.koneksidatabase

data class FakultasModel(val id_fakultas: Int, val kode_fakultas: String, val nama_fakultas: String) {


}